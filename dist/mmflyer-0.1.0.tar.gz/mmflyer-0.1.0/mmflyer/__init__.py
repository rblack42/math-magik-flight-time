name = 'mmflyer'
__version__ = "v0.1.0"


def version():
    return __version__
