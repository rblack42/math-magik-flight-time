from .cli import cli

# python -m mmflyer
if __name__ == '__main__':
    cli()
